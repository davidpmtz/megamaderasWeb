@extends('app')

@section('css')
<link rel="stylesheet" href="{{asset('css/base.css')}}">
@endsection

@section('header')
		<div class='ten columns'>
			<h1>MegaMaderas S.A de C.V</h1> 
			<h2>No te confundas. nosotros somos tu mejor opción!!!</h2>
		</div>

		<div class='six columns'>
			<h4>Oferta del día</h4>
			<p>Adquiere un tablón de cedro puro y nosotros te regalamos e instalos los herrages necesarios. =)</p>
			<a href='#' class='button medium green'>Ver oferta</a>
		</div>
@endsection


<div class='clear'></div>
<div class='clear'></div>

@section('content')

@endsection
@endsection
